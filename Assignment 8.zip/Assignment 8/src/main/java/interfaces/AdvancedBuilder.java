package interfaces;

public interface AdvancedBuilder {

    public void buildHouse(String location);
    public void buildSkyscrappers(String location);


}
