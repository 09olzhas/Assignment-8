package domain;

import interfaces.AdvancedBuilder;

public class SkyscrapperBuilder implements AdvancedBuilder {

    public void buildSkyscrappers(String location) {
        System.out.println("Building skyscrapper in the " + location + "area!");
    }

    public void buildHouse(String location) {

    }

}
