import domain.BuilderImplementation;

public class Main {

    public static void main(String[] args) {
        BuilderImplementation buildImpl = new BuilderImplementation();
        buildImpl.build("House" , "CityCenter");
        buildImpl.build("Skyscrapper" , "Downtown");
        buildImpl.build("Floor" , "CityCenter");
    }
}
